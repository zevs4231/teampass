<?php
/**
 * @package       folders.load.php
 * @author        Nils Laumaillé <nils@teampass.net>
 * @version       2.1.27
 * @copyright     2009-2019 Nils Laumaillé
 * @license       GNU GPL-3.0
 * @link          https://www.teampass.net
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

if (!isset($_SESSION['CPM']) || $_SESSION['CPM'] != 1) {
    die('Hacking attempt...');
}
?>

<script type="text/javascript">
//<![CDATA[
    

$.extend($.expr[":"], {
    "containsIN": function(elem, i, match, array) {
        return (elem.textContent || elem.innerText || "").toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
    }
});

// prepare Alphabet
var _alphabetSearch = '';
$.fn.dataTable.ext.search.push( function ( settings, searchData ) {
    if ( ! _alphabetSearch ) {
        return true;
    }
    if ( searchData[0].charAt(0) === _alphabetSearch ) {
        return true;
    }
    return false;
} );

$(function() {
    $("#span_new_rep_roles").hide();

    //Launch the datatables pluggin
    var tableFolders = $("#t_folders").dataTable({
        "order": [[ 1, "asc" ]],
        "ordering": false,
        "searching": false,
        "paging": false,
        "processing": true,
        "serverSide": true,
        "ajax": {
            url: "<?php echo $SETTINGS['cpassman_url']; ?>/sources/datatable/datatable.folders.php?token=<?php echo $_SESSION["key"]; ?>",
            data: function(d) {
                d.letter = _alphabetSearch
            }
        },
        "language": {
            "url": "<?php echo $SETTINGS['cpassman_url']; ?>/includes/language/datatables.<?php echo $_SESSION['user_language']; ?>.txt"
        },
        "columns": [
            {"width": "7%"},
            {"width": "5%"},
            {className: "dt-body-left"},
            {"width": "5%"},
            {"width": "15%"},
            {"width": "10%"},
            {"width": "10%"},
            {"width": "5%"},
            {"width": "5%"},
            {"width": "5%"}
        ]
    });
    
    // manage the Alphabet
    var alphabet = $('<div class="alphabet"/>').append( 'Search: ' );
    $('<span class="clear active"/>')
        .data( 'letter', '' )
        .html( 'None' )
        .appendTo( alphabet );
    for ( var i=0 ; i<26 ; i++ ) {
        var letter = String.fromCharCode( 65 + i );

        $('<span/>')
            .data( 'letter', letter )
            .html( letter )
            .appendTo( alphabet );
    }
    alphabet.insertBefore( "#t_folders_alphabet" );
    alphabet.on( 'click', 'span', function () {
        alphabet.find( '.active' ).removeClass( 'active' );
        $(this).addClass( 'active' );

        _alphabetSearch = $(this).data('letter');

        tableFolders.api().ajax.reload();
    } );


    $("#div_add_group").dialog({
        bgiframe: true,
        modal: true,
        autoOpen: false,
        width: 450,
        height: 460,
        title: "<?php echo $LANG['add_new_group']; ?>",
        open: function(event, ui) {
            $("#new_folder_wait").hide();

            //empty dialogbox
            $("#div_add_group input, #div_add_group select, #new_rep_roles").val("");
            $("#add_node_renewal_period").val("0");
            $("#folder_block_modif, #folder_block_creation").val("0");
            $("#parent_id").val("na");
        },
        buttons: {
            "<?php echo $LANG['save_button']; ?>": function() {
                //Check if renewal_period is an integer
                if (isInteger(document.getElementById("add_node_renewal_period").value) === false) {
                    document.getElementById("addgroup_show_error").innerHTML = "<?php echo $LANG['error_renawal_period_not_integer']; ?>";
                    $("#addgroup_show_error").show();
                } else if (document.getElementById("new_rep_complexite").value == "") {
                    document.getElementById("addgroup_show_error").innerHTML = "<?php echo $LANG['error_group_complex']; ?>";
                    $("#addgroup_show_error").show();
                } else if (document.getElementById("parent_id").value == "" || isNaN(document.getElementById("parent_id").value)) {
                    document.getElementById("addgroup_show_error").innerHTML = "<?php echo $LANG['error_no_selected_folder']; ?>";
                    $("#addgroup_show_error").show();
                } else {
                    if (document.getElementById("ajouter_groupe_titre").value != "" && document.getElementById("parent_id").value != "na") {
                        $("#new_folder_wait").show();
                        $("#addgroup_show_error").hide();
                        //prepare data
                        var data = {
                            "title":$('#ajouter_groupe_titre').val().replace(/"/g,'&quot;') ,
                            "complexity": $('#new_rep_complexite').val().replace(/"/g,'&quot;'),
                            "parent_id": $('#parent_id').val().replace(/"/g,'&quot;') ,
                            "renewal_period": $('#add_node_renewal_period').val().replace(/"/g,'&quot;') ,
                            "block_creation": $("#folder_block_creation").val() ,
                            "block_modif": $("#folder_block_modif").val(),
                            "access_level": $("#new_rep_roles").val()
                        };

                        //send query
                        $.post(
                            "sources/folders.queries.php",
                            {
                                type    : "add_folder",
                                data    : prepareExchangedData(JSON.stringify(data), "encode", "<?php echo $_SESSION['key']; ?>"),
                                key     : "<?php echo $_SESSION['key']; ?>"
                            },
                            function(data) {
                                //Check errors
                                if (data[0].error == "error_group_exist") {
                                    $("#div_add_group").dialog("open");
                                    $("#addgroup_show_error").html("<?php echo $LANG['error_group_exist']; ?>");
                                    $("#addgroup_show_error").show();
                                } else if (data[0].error == "error_html_codes") {
                                    $("#div_add_group").dialog("open");
                                    $("#addgroup_show_error").html("<?php echo $LANG['error_html_codes']; ?>");
                                    $("#addgroup_show_error").show();
                                } else if (data[0].error == "error_title_only_with_numbers") {
                                    $("#div_add_group").dialog("open");
                                    $("#addgroup_show_error").html("<?php echo $LANG['error_only_numbers_in_folder_name']; ?>");
                                    $("#addgroup_show_error").show();
                                } else if (data[0].error == "error_pwd_compexity_not_reached") {
                                    $("#div_add_group").dialog("open");
                                    $("#addgroup_show_error").html(data[0].msg);
                                    $("#addgroup_show_error").show();
                                } else {
                                    tableFolders.api().ajax.reload();
                                    $("#parent_id, #edit_parent_id")
                                        .empty()
                                        .append(data[0].droplist);
                                    $("#div_add_group").dialog("close");
                                }
                                $("#new_folder_wait").hide();
                            },
                            "json"
                       );
                    } else {
                        document.getElementById("addgroup_show_error").innerHTML = "<?php echo $LANG['error_fields_2']; ?>";
                        $("#addgroup_show_error").show();
                    }
                }
            },
            "<?php echo $LANG['cancel_button']; ?>": function() {
                $("#addgroup_show_error").html("").hide();
                $(this).dialog("close");
            }
        }
    });

    $("#div_edit_folder").dialog({
        bgiframe: true,
        modal: true,
        autoOpen: false,
        width: 450,
        height: 460,
        title: "<?php echo $LANG['at_category']; ?>",
        open: function(event, ui) {
            var id = $("#folder_id_to_edit").val();
            $("#edit_folder_wait").hide();
            
            //update dialogbox with data
            $("#edit_folder_title").val($("#title_"+id).text());
            $("#edit_folder_renewal_period").val($("#renewal_"+id).text());
            $("#edit_folder_complexite").val($("#renewal_id_"+id).val());
            $("#edit_parent_id option[value='"+$("#parent_id_"+id).val()+"']").prop('selected', true);
            $("#edit_folder_block_creation").val($("#block_creation_"+id).val());
            $("#edit_folder_block_modif").val($("#block_modif_"+id).val());
        },
        buttons: {
            "<?php echo $LANG['delete']; ?>": function() {
                if (confirm("<?php echo $LANG['confirm_delete_group']; ?>")) {
                    //send query
                    $.post(
                        "sources/folders.queries.php",
                        {
                            type    : "delete_folder",
                            id      : $("#folder_id_to_edit").val(),
                            key     : "<?php echo $_SESSION['key']; ?>"
                        },
                        function(data) {
                            tableFolders.api().ajax.reload();
                            $("#div_edit_folder").dialog("close");
                        }
                    );
                }

                //Close
                $("#div_edit_folder").dialog("close");
            },
            "<?php echo $LANG['save_button']; ?>": function() {
                if ($('#edit_folder_complexite').val() == "") {
                     $("#edit_folder_show_error").html("<?php echo $LANG['error_group_complex']; ?>").show();
                     return;
                }if ($('#edit_folder_title').val() == "") {
                     $("#edit_folder_show_error").html("<?php echo $LANG['error_group_label']; ?>").show();
                     return;
                }if ($('#edit_parent_id').val() == "na") {
                     $("#edit_folder_show_error").html("<?php echo $LANG['error_no_selected_folder']; ?>").show();
                     return;
                }
                $("#edit_folder_wait").show();
                //prepare data
                var data = '{"id":"'+$("#folder_id_to_edit").val()+'", "title":"'+$('#edit_folder_title').val().replace(/"/g,'&quot;') + '", "complexity":"'+$('#edit_folder_complexite').val().replace(/"/g,'&quot;')+'", '+
                '"parent_id":"'+$('#edit_parent_id').val().replace(/"/g,'&quot;')+'", "renewal_period":"'+$('#edit_folder_renewal_period').val().replace(/"/g,'&quot;')+'" , "block_creation":"'+$("#edit_folder_block_creation").val()+'" , "block_modif":"'+$("#edit_folder_block_modif").val()+'"}';

                //send query
                $.post(
                    "sources/folders.queries.php",
                    {
                        type    : "update_folder",
                        data      : prepareExchangedData(data, "encode", "<?php echo $_SESSION['key']; ?>"),
                        key        : "<?php echo $_SESSION['key']; ?>"
                    },
                    function(data) {
                        //decrypt data
                        data = prepareExchangedData(data, "decode", "<?php echo $_SESSION['key']; ?>");

                        $("#edit_folder_wait").hide();
                        //Check errors
                        if (data.error === "error_title_only_with_numbers") {
                            $("#edit_folder_show_error").html("<?php echo $LANG['error_only_numbers_in_folder_name']; ?>").show();
                        } else if (data.error === "error_group_exist") {
                            $("#edit_folder_show_error").html("<?php echo $LANG['error_group_exist']; ?>").show();
                        } else if (data.error === "error_html_codes") {
                            $("#edit_folder_show_error").html("<?php echo $LANG['error_html_codes']; ?>").show();
                        } else if (data.error === "error_folder_complexity_lower_than_top_folder") {
                            $("#edit_folder_show_error").html(data.error_msg).show();
                        } else {
                            $("#folder_id_to_edit").val("");    //clear id
                            tableFolders.api().ajax.reload();
                            $("#parent_id, #edit_parent_id")
                                .find('option')
                                .remove()
                                .end()
                                .append(data.droplist);
                            $("#div_edit_folder").dialog("close");
                        }
                    }
               );
            },
            "<?php echo $LANG['cancel_button']; ?>": function() {
                //clear id
                $("#folder_id_to_edit").val("");
                $("#edit_folder_show_error").html("");

                //Close
                $("#div_edit_folder").dialog("close");
            }
        }
    });

    // manage the click on toggle icons
    $(document).on({
        click: function (event) {
            $("#div_loading").show();
            if ($(this).attr('tp') === undefined) {
                // case of folder selection
                var selected_cb = $(this);
                var elem = $(this).attr("id").split("-");
                if ($(this).prop("checked") === true) {
                    $("#row_"+elem[1]).css({"font-weight":"bold"});
                    $("#title_"+elem[1]).css({"background-color":"#E9FF00"});
                } else {
                    $("#row_"+elem[1]).css({"font-weight":""});
                    $("#title_"+elem[1]).css({"background-color":"#FFF"});
                }

                // send change to be stored
                $.post(
                    "sources/folders.queries.php",
                    {
                        type    : "select_sub_folders",
                        id      : elem[1],
                        key     : "<?php echo $_SESSION['key']; ?>"
                    },
                    function(data) {
                        $("#div_loading").hide();
                        // check/uncheck checkbox
                        if (data[0].subfolders !== "") {
                            var tmp = data[0].subfolders.split(";");
                            for (var i = tmp.length - 1; i >= 0; i--) {
                                if (selected_cb.prop("checked") === true) {
                                    $("#cb_selected-" + tmp[i]).prop("checked", true).prop("disabled", true);
                                    $("#row_" + tmp[i]).css({"font-weight":"bold"});
                                    $("#title_" + tmp[i]).css({"background-color":"#E9FF00"});
                                } else {
                                    $("#cb_selected-" + tmp[i]).prop("checked", false).prop("disabled", false);
                                    $("#row_" + tmp[i]).css({"font-weight":""});
                                    $("#title_" + tmp[i]).css({"background-color":"#FFF"});
                                }
                            }
                        }
                    },
                    "json"
                );
            } else {
                var tmp = $(this).attr('tp').split('-');    //[0]>ID ; [1]>action  ; [2]>NewValue

                // send change to be stored
                $.post(
                    "sources/folders.queries.php",
                    {
                        type    : tmp[1],
                        value   : tmp[2],
                        id      : tmp[0],
                        key        : "<?php echo $_SESSION['key']; ?>"
                    },
                    function(data) {
                        $("#div_loading").hide();
                        // refresh table content
                        tableFolders.api().ajax.reload();
                    }
                );
            }
        }
    },
    ".fa-toggle-off, .fa-toggle-on, .cb_selected_folder"
    );

    //
    $( "#click_delete_multiple_folders" ).click(function() {
        var list_i = "";
        $(".cb_selected_folder:checked").each(function() {
            var elem = $(this).attr("id").split("-");
            if (list_i == "") list_i = elem[1];
            else list_i = list_i+';'+elem[1];
        });
        if (list_i != "" && $("#action_on_going").val() == "" && confirm("<?php echo addslashes($LANG['confirm_deletion']); ?>")) {
            $("#div_loading").show();
            $("#action_on_going").val("multiple_folders");
            var data = '{"foldersList":"'+list_i+'"}';
            //send query
            $.post(
                "sources/folders.queries.php",
                {
                    type    : "delete_multiple_folders",
                    data    : prepareExchangedData(data, "encode", "<?php echo $_SESSION['key']; ?>"),
                    key     : "<?php echo $_SESSION['key']; ?>"
                },
                function(data) {
                    tableFolders.api().ajax.reload();
                    $("#action_on_going").val("");
                    $("#div_loading").hide();
                },
                "json"
           );
        }
    });

    $("#click_refresh_folders_list").click(function() {
        tableFolders.api().ajax.reload();
    });

    $("#parent_id").change(function() {
        if ($(this).val() === "0") {
            $("#span_new_rep_roles").show();
        } else {
            $("#span_new_rep_roles").hide();
        }
    })
});


/**
 *
 * @access public
 * @return void
 **/
function open_edit_folder_dialog(id)
{
    $("#folder_id_to_edit").val(id);console.log(">"+id);
    $("#div_edit_folder").dialog("open");
}
//]]>
</script>
